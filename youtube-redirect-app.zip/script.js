// script.js
// Replace 'YOUR_CHANNEL' placeholders in HTML title and links with your actual channel URL programmatically if desired.
// By default the files already contain placeholders to replace manually.

(function(){
  // Put current year in footer
  var y = new Date().getFullYear();
  var yearEl = document.getElementById('year');
  if(yearEl) yearEl.textContent = y;

  // Optional: Try to open YouTube app via intent when clicking the button (Android).
  var btn = document.getElementById('open-channel');
  if(btn){
    btn.addEventListener('click', function(e){
      var href = btn.getAttribute('href');
      // Construct intent link for Android to prefer opening the YouTube app.
      // This will fallback to the normal https link if intent fails.
      // Note: some browsers may block intent navigation; this is an attempt.
      var channelUrl = href;
      var channelIdOrName = href.replace(/^https?:\/\//i, '');
      // Example intent: intent://www.youtube.com/@YourChannel#Intent;package=com.google.android.youtube;scheme=https;end
      var intentUrl = 'intent://' + channelIdOrName + '#Intent;package=com.google.android.youtube;scheme=https;end';
      // For safety, we open the intent in a short timeout so the click still works as regular link in browsers.
      setTimeout(function(){
        window.location.href = intentUrl;
      }, 150);
      // Let the anchor's default behavior continue (opens in new tab due to target="_blank")
    });
  }
})();
