# youtube-redirect-app

Simple GitHub Pages ready project that redirects / links users to your YouTube channel.
Replace the placeholder URL `https://www.youtube.com/@YOUR_CHANNEL` in `index.html` (title and link hrefs)
with your actual YouTube channel link (for example: `https://www.youtube.com/@YourChannelName` or `https://www.youtube.com/channel/UCxxxxxx`).

Files:
- index.html  — main page (header, footer, large YouTube-style open button)
- style.css   — styling
- script.js   — small script (year, intent-link behavior)
- README.md   — this file

How to deploy to GitHub Pages:
1. Create a new repository on GitHub.
2. Upload all files from this folder to the repository root.
3. In the repo: Settings → Pages → Source → Select branch `main` and `/ (root)`.
4. Save — your site will be available at `https://your-username.github.io/repo-name`.

Once deployed you can use the page URL inside an Android WebView app or a simple wrapper to publish on Play Store.
